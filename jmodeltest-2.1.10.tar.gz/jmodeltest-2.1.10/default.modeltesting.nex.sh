#!/bin/bash

#Reads in a batch of files (fasta format) in /Applications/jmodeltest-2.1.7/DataFiles and finds the best-fit model according to AICc

cd /Applications/jmodeltest-2.1.7/DataFiles
for f in *.nex
do
java -jar /Applications/jmodeltest-2.1.7/jModelTest.jar -d $f  -s 11 -i -g 4 -f -AICc -a -tr 6 -S NNI -t BIONJ -o $f.jMT.txt
done
