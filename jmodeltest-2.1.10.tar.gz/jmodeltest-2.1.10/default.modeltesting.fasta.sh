#!/bin/bash

#Reads in a batch of files (fasta format) in /Applications/jmodeltest-2.1.7/DataFiles and finds the best-fit model according to AICc

cd /opt/jmodeltest-2.1.10/DataFiles
for f in *.fas*
do
java -jar /opt/jmodeltest-2.1.10/jModelTest.jar -d $f  -s 11 -i -g 4 -f -AICc -a -tr 6 -S NNI -t BIONJ -o $f.jMT.txt
done
